mystr = u'12,12,14,'
mystr.encode('utf-8')
print mystr
