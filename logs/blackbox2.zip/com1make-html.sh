#!/usr/bin/bash

cat com1saving.header > com1saving.html
cat com1saving.txt >> com1saving.html
cat com1saving.footer >> com1saving.html
